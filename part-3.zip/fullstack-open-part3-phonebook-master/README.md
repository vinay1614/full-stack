# Full Stack Open '19 - Part 3 - Exercises

A tiny phonebook web app.

Keeping the code in the same repo:

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\backend - Node.js server<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\frontend - React UI

Running on Heroku:

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;https://polite-toque-27621.herokuapp.com/
